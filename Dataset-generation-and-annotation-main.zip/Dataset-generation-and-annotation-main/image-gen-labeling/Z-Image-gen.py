import warnings

warnings.filterwarnings('ignore')

import os, tqdm, random, shutil
import torch
from diffusers import ZImagePipeline


class ImageGenerator:
    def __init__(self, model_name='Z-Image-Turbo'):
        self.pipe = None
        if model_name == 'Z-Image-Turbo':
            self.pipe = ZImagePipeline.from_pretrained(
                "/datasets/studio/huggingface/models/Z-Image-Turbo",
                torch_dtype=torch.bfloat16,
                low_cpu_mem_usage=False,
            )
            self.pipe.to("cuda")
            # Diffusers uses SDPA by default. Switch to Flash Attention for better efficiency if supported:
            self.pipe.transformer.set_attention_backend("flash")

    def __call__(self, prompt, save_path):
        image = self.pipe(
            prompt=prompt,
            height=720,
            width=1280,
            num_inference_steps=9,  # This actually results in 8 DiT forwards
            guidance_scale=0.0,  # Guidance should be 0 for the Turbo models
            generator=torch.Generator("cuda").manual_seed(torch.randint(0, 2 ** 32, (1,)).item()),
        ).images[0]

        image.save(save_path)


def generate_uav_road_defect_prompts():
    """生成所有无人机视角道路缺陷检测 prompt 组合"""

    # 道路缺陷类型
    defect_types = [
        'one or several transverse pavement cracks extending across the driving direction, thin irregular dark surface lines with realistic widths of 3-15 millimeters, subtle branching and natural width variation',
        'one or several longitudinal pavement cracks extending approximately parallel to the driving direction, thin discontinuous dark surface lines with realistic widths of 3-15 millimeters',
        'one or several diagonal pavement cracks extending obliquely across the traffic lane, narrow irregular lines with a few short secondary branches and realistic widths of 3-15 millimeters',
        'localized network cracking composed of many fine interconnected polygonal surface lines within an area of approximately 0.5-2 square meters, without wide polygon gaps',
        'one or several small shallow potholes with irregular worn edges, realistic diameters of 15-60 centimeters and depths of approximately 1-5 centimeters',
        'one or several flat asphalt repair patches with rectangular or irregular boundaries, subtle color differences, realistic dimensions of 0.5-3 meters and narrow closed repair seams'
    ]

    # 缺陷数量与分布
    counts = [
        'a single localized pavement defect surrounded by mostly intact asphalt',
        '2 separated pavement defects with large intact road areas between them',
        '3 small pavement defects sparsely distributed within one traffic lane',
        '4-5 localized pavement defects distributed along a short road section',
        'several small pavement defects sparsely distributed across adjacent traffic lanes'
    ]

    # 天气与光照条件
    lightings = [
        'light rain with fine raindrops, uniformly wet asphalt, soft reflections and slightly reduced contrast',
        'moderate rain with visible rainfall, wet pavement, small shallow puddles and mild road spray',
        'steady rain with water-darkened asphalt, scattered reflections and realistic limited visibility',
        'after rain with damp pavement, irregular water stains, shallow puddles and reflected sky light',
        'light snowfall with sparse snowflakes, thin snow near the road edges and mostly exposed asphalt',
        'moderate snowfall with discontinuous snow coverage, slush and visible tire tracks',
        'after snowfall with small snow patches, slush along the curbs and exposed pavement around the defects',
        'winter weather with thin uneven snow coverage while the main road defects remain visible',
        'light fog with soft atmospheric haze, slightly reduced contrast and clear nearby pavement texture',
        'moderate fog with muted colors, diffused light and reduced long-distance visibility',
        'dense morning fog with low contrast while the inspected road section remains visible',
        'fog after rain with wet pavement, soft reflections and hazy surrounding scenery',
        'nighttime illuminated by evenly spaced street lamps with realistic shadows and mild sensor noise',
        'rainy night with controlled wet-road reflections, street lighting and limited headlight glare',
        'foggy night with diffused street lamps, low contrast and visible pavement texture',
        'very low-light dawn or dusk with dim ambient illumination, subtle noise and preserved defect details'
    ]

    # 缺陷遮挡情况
    occlusions = [
        'fully visible on the exposed road surface with no object covering the defect',
        'slightly affected by soft shadows while the complete defect geometry remains visible',
        'seen through a thin transparent water film without changing its physical dimensions',
        'partially surrounded by snow or slush while most of the defect remains exposed',
        'located near sparse vehicles without being covered by vehicles or strong shadows'
    ]

    # 无人机视角与飞行高度
    viewpoints = [
        "low-altitude UAV view from 15-30 meters with a stabilized top-down bird's-eye perspective at 90 degrees",
        'medium-altitude UAV view from 30-50 meters with a stabilized near-vertical perspective at 82-88 degrees'
    ]

    # 道路背景环境
    backgrounds = [
        'straight urban asphalt road with lane markings, intact sidewalks, roadside vegetation and guardrails',
        'wide multilane city avenue with intact intersections, traffic signs, street lights and roadside buildings',
        'residential asphalt road with parked vehicles, intact curbs, trees and drainage facilities',
        'highway or bridge pavement with intact guardrails, emergency lanes and directional markings',
        'road intersection or T-junction with intact zebra crossings, turning arrows, manhole covers and sidewalks'
    ]

    prompts = []

    # 遍历所有组合
    for defect_type in defect_types:
        for count in counts:
            for lighting in lightings:
                for occlusion in occlusions:
                    for viewpoint in viewpoints:
                        for background in backgrounds:
                            prompt = f"""Photorealistic aerial UAV image for road pavement defect detection.
{count} consisting exclusively of {defect_type}.
{lighting}. The pavement defect is {occlusion}.
{viewpoint}. {background}.
The visual scale and appearance of the pavement damage must match real UAV road inspection photographs.
Linear cracks appear as narrow dark gray or black surface lines embedded in the asphalt texture, with subtle jagged paths, slight discontinuities, occasional short branches and low-contrast edges.
At UAV image scale, each linear crack should appear only as a very thin line, normally about one twentieth to one sixth of the width of a nearby lane marking.
Only a few short local crack junctions may appear slightly darker or thicker, but no part may resemble a trench, canyon, structural separation or open ground gap.
The asphalt aggregate texture remains visible immediately beside the crack, with no vertical sidewalls, exposed soil, deep interior shadow or displaced pavement slabs.
Transverse, longitudinal and diagonal cracks may extend for several meters across the road while remaining consistently thin and shallow.
Network cracking remains confined to small localized pavement regions and consists of fine interconnected lines rather than large separated polygon blocks.
Potholes remain localized, shallow and naturally worn, with no crater-like depth or catastrophic pavement collapse.
Repair patches remain flat and level with the surrounding road, with subtle tonal variation and narrow realistic seams.
All cracks, potholes and repair patches are physically confined to the drivable asphalt or concrete carriageway.
Sidewalks, curbs, buildings, roofs, walls, vehicles, guardrails, traffic signs, soil, vegetation and every other non-road surface remain intact and completely free of cracks.
The defects remain distinguishable from lane markings, painted arrows, shadows, tire marks, oil stains, water reflections, snow boundaries, manhole covers, drainage grates and normal asphalt texture.
No giant cracks, no exaggerated black fissures, no earthquake damage, no ground rupture, no road splitting, no collapsed pavement and no damage outside the road surface.
Realistic rain, snow, fog, nighttime and low-light imaging effects, natural colors, physically plausible illumination and professional UAV road inspection photography, 4K quality."""
                            prompts.append(prompt.replace('\n', ' ').strip())

    return prompts, 'road_defect_gen'


if __name__ == '__main__':
    model = ImageGenerator('Z-Image-Turbo')
    gen_image_num = 8000
    all_prompts, save_folder = generate_uav_road_defect_prompts()
    # all_prompts, save_folder = generate_uav_vehicle_prompts()
    random.shuffle(all_prompts)
    save_folder = os.path.join(save_folder, 'images')
    if not os.path.exists(save_folder):
        os.makedirs(save_folder)
    for idx in tqdm.tqdm(range(gen_image_num)):
        model(all_prompts[idx], f'{save_folder}/image_{idx:06d}.png')