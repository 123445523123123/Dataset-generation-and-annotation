"""
目标检测与可视化工具
使用 LLMDet 模型进行零样本目标检测，并生成 YOLO 格式标签
"""

import os
from pathlib import Path
from typing import List, Dict, Tuple

import cv2
import torch
import tqdm
from transformers import AutoModelForZeroShotObjectDetection, AutoProcessor
from transformers.image_utils import load_image


# ==================== 常量定义 ====================

COLORS = [
    (255, 0, 0),      # 蓝色
    (0, 255, 0),      # 绿色
    (0, 0, 255),      # 红色
    (255, 255, 0),    # 青色
    (255, 0, 255),    # 洋红色
    (0, 255, 255),    # 黄色
    (128, 0, 128),    # 紫色
    (255, 128, 0),    # 橙色
    (0, 128, 255),    # 天蓝色
    (128, 255, 0),    # 黄绿色
    (255, 0, 128),    # 粉红色
    (0, 255, 128),    # 春绿色
    (128, 128, 0),    # 橄榄色
    (128, 0, 0),      # 深蓝色
    (0, 128, 128),    # 深青色
    (0, 0, 128),      # 深红色
    (255, 165, 0),    # 亮橙色
    (75, 0, 130),     # 靛青色
    (238, 130, 238),  # 紫罗兰色
    (0, 128, 0)       # 深绿色
]


# ==================== 数据转换函数 ====================

def convert_to_yolo_format(
    image_path: str,
    detections: List[Dict],
    class_names: List[str],
) -> List[str]:
    """
    将检测结果转换为 YOLO 格式
    
    Args:
        image_path: 图像路径
        detections: 检测结果列表，每个元素包含 class_name, confidence, bbox
        class_names: 类别名称列表
        
    Returns:
        YOLO 格式的标签列表
    """
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"无法读取图像: {image_path}")
    
    img_height, img_width = img.shape[:2]
    yolo_labels = []
    
    for detection in detections:
        class_name = detection['class_name']
        x1, y1, x2, y2 = detection['bbox']
        
        # 过滤不符合条件的检测结果
        if class_name not in class_names:
            continue
        
        # 计算 YOLO 格式参数
        class_id = class_names.index(class_name)
        center_x = (x1 + x2) / 2 / img_width
        center_y = (y1 + y2) / 2 / img_height
        width = (x2 - x1) / img_width
        height = (y2 - y1) / img_height
        
        yolo_labels.append(f'{class_id} {center_x} {center_y} {width} {height}')
    
    return yolo_labels


# ==================== 可视化函数 ====================

def visualize_detections(
    image_path: str,
    detections: List[Dict],
    save_path: str
) -> None:
    """
    可视化检测结果并保存
    
    Args:
        image_path: 原始图像路径
        detections: 检测结果列表
        save_path: 保存路径
    """
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"无法读取图像: {image_path}")
    
    img_height, img_width = img.shape[:2]
    
    # 绘制每个检测框
    for detection in detections:
        _draw_single_detection(img, detection, img_width, img_height)
    
    # 添加统计信息
    info_text = f"Detected: {len(detections)} objects"
    cv2.putText(img, info_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                1, (0, 255, 0), 2)
    
    # 保存结果
    cv2.imwrite(save_path, img)


def _draw_single_detection(
    img,
    detection: Dict,
    img_width: int,
    img_height: int
) -> None:
    """
    在图像上绘制单个检测结果
    
    Args:
        img: OpenCV 图像对象
        detection: 单个检测结果
        img_width: 图像宽度
        img_height: 图像高度
    """
    class_name = detection['class_name']
    confidence = detection['confidence']
    x1, y1, x2, y2 = map(int, detection['bbox'])
    
    # 确保坐标在图像范围内
    x1 = max(0, min(x1, img_width))
    y1 = max(0, min(y1, img_height))
    x2 = max(0, min(x2, img_width))
    y2 = max(0, min(y2, img_height))
    
    # 获取颜色
    color = COLORS[detection['class_id']]
    
    # 绘制边界框
    cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
    
    # 绘制标签
    _draw_label(img, class_name, confidence, x1, y1, color)


def _draw_label(
    img,
    class_name: str,
    confidence: float,
    x: int,
    y: int,
    color: Tuple[int, int, int]
) -> None:
    """
    在检测框上方绘制标签
    
    Args:
        img: OpenCV 图像对象
        class_name: 类别名称
        confidence: 置信度
        x, y: 标签位置
        color: 标签颜色
    """
    label = f"{class_name}: {confidence:.2f}"
    
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.6
    thickness = 2
    
    # 计算文本大小
    (text_width, text_height), baseline = cv2.getTextSize(
        label, font, font_scale, thickness
    )
    
    # 绘制文本背景
    cv2.rectangle(
        img,
        (x, y - text_height - baseline - 5),
        (x + text_width, y),
        color,
        -1
    )
    
    # 绘制文本
    cv2.putText(
        img,
        label,
        (x, y - baseline - 5),
        font,
        font_scale,
        (255, 255, 255),
        thickness
    )


# ==================== 模型推理函数 ====================

def load_model(model_path: str, device: str):
    """
    加载模型和处理器
    
    Args:
        model_path: 模型路径
        device: 运行设备 ('cuda' 或 'cpu')
        
    Returns:
        processor, model
    """
    processor = AutoProcessor.from_pretrained(model_path)
    model = AutoModelForZeroShotObjectDetection.from_pretrained(model_path).to(device)
    return processor, model


def process_detection_results(
    results,
    target_labels: List[str]
) -> List[Dict]:
    """
    处理模型输出，转换为标准格式
    
    Args:
        results: 模型输出结果
        target_labels: 目标标签列表
        
    Returns:
        标准格式的检测结果列表
    """
    detections = []
    
    for box, score, label in zip(
        results['boxes'].tolist(),
        results['scores'],
        results['text_labels']
    ):
        if label in target_labels:
            detections.append({
                'class_id': target_labels.index(label),
                'class_name': label,
                'confidence': float(score),
                'bbox': box
            })
    
    return detections


def batch_inference(
    model,
    processor,
    image_paths: List[str],
    labels: List[str],
    device: str,
    confidence_threshold: float = 0.2
) -> List[List[Dict]]:
    """
    批量推理
    
    Args:
        model: 检测模型
        processor: 图像处理器
        image_paths: 图像路径列表
        labels: 检测标签列表
        device: 运行设备
        confidence_threshold: 置信度阈值
        
    Returns:
        每张图像的检测结果列表
    """
    # 加载图像
    images = [load_image(path) for path in image_paths]
    
    # 所有图片使用同一套标签
    text_labels = [labels for _ in image_paths]
    
    # 准备输入
    inputs = processor(images=images, text=text_labels, return_tensors="pt").to(device)
    
    # 推理
    with torch.no_grad():
        outputs = model(**inputs)
    
    # 后处理
    target_sizes = [(img.height, img.width) for img in images]
    results = processor.post_process_grounded_object_detection(
        outputs,
        threshold=confidence_threshold,
        target_sizes=target_sizes
    )
    
    # 转换为标准格式
    all_detections = []
    for idx, result in enumerate(results):
        detections = process_detection_results(result, labels)
        all_detections.append(detections)
    
    return all_detections


# ==================== 文件处理函数 ====================

def save_yolo_labels(
    yolo_labels: List[str],
    save_path: str
) -> None:
    """
    保存 YOLO 格式标签
    
    Args:
        yolo_labels: YOLO 格式标签列表
        save_path: 保存路径
    """
    with open(save_path, 'w') as f:
        f.write('\n'.join(yolo_labels))


def ensure_directories_exist(*dirs: str) -> None:
    """
    确保目录存在，不存在则创建
    
    Args:
        *dirs: 目录路径列表
    """
    for directory in dirs:
        Path(directory).mkdir(parents=True, exist_ok=True)


# ==================== 主函数 ====================

def main():
    """主函数：批量处理图像检测"""
    
    # ========== 配置参数 ==========
    MODEL_PATH = "/root/.cache/huggingface/hub/models--iSEE-Laboratory--llmdet_large/snapshots/bec37f296f05b22f6c6b39bc05a6c611239f4e31"
    IMAGE_DIR = '/root/image-gen/uav_gen/images'
    LABEL_DIR = '/root/image-gen/uav_gen/labels'
    VISUAL_DIR = '/root/image-gen/visual'
    
    # DETECTION_LABELS = ['a apple']
    DETECTION_LABELS = ['car',           # 小汽车（轿车、SUV等）
                        'truck',         # 卡车
                        'bus',           # 公交车/大巴
                        'van',           # 面包车
                        'motorcycle',    # 摩托车/电动车
                        'bicycle',       # 自行车
                        'person',        # 行人
                        ]
    BATCH_SIZE = 4
    DETECTION_THRESHOLD = 0.2
    
    # ========== 初始化 ==========
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"使用设备: {device}")
    
    # 创建输出目录
    ensure_directories_exist(LABEL_DIR, VISUAL_DIR)
    
    # 加载模型
    print("加载模型...")
    processor, model = load_model(MODEL_PATH, device)
    
    # 获取图像列表
    image_names = os.listdir(IMAGE_DIR)
    total_images = len(image_names)
    print(f"共 {total_images} 张图像待处理")
    
    # ========== 批量处理 ==========
    for batch_start in tqdm.tqdm(range(0, total_images, BATCH_SIZE), desc="处理进度"):
        # 获取当前批次的图像
        batch_names = image_names[batch_start:batch_start + BATCH_SIZE]
        batch_paths = [os.path.join(IMAGE_DIR, name) for name in batch_names]
        
        # 批量推理
        batch_detections = batch_inference(
            model=model,
            processor=processor,
            image_paths=batch_paths,
            labels=DETECTION_LABELS,
            device=device,
            confidence_threshold=DETECTION_THRESHOLD
        )
        
        # 处理每张图像的结果
        for idx, (image_name, image_path, detections) in enumerate(
            zip(batch_names, batch_paths, batch_detections)
        ):
            # 转换为 YOLO 格式
            yolo_labels = convert_to_yolo_format(
                image_path=image_path,
                detections=detections,
                class_names=DETECTION_LABELS
            )
            
            # 保存标签
            label_path = os.path.join(
                LABEL_DIR,
                image_name.replace('.png', '.txt')
            )
            save_yolo_labels(yolo_labels, label_path)
            
            # 可视化并保存
            visual_path = os.path.join(VISUAL_DIR, image_name)
            visualize_detections(image_path, detections, visual_path)
    
    print(f"\n处理完成！")
    print(f"标签保存路径: {LABEL_DIR}")
    print(f"可视化保存路径: {VISUAL_DIR}")


if __name__ == '__main__':
    main()