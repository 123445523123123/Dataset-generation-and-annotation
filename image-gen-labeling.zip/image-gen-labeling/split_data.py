#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Split YOLO dataset into train/val/test while supporting multiple image formats.

Default behavior:
- Split by label .txt files, which matches common YOLO detection datasets.
- For each label stem, find the corresponding image by trying multiple extensions.
- Preserve the original image extension when copying.
- Generate split_summary.csv and missing_images.txt for traceability.

Example:
python split_data_improved.py \
  --img-dir D:/SD/Dataest/UAV-PDD2023/Images \
  --label-dir D:/SD/Dataest/UAV-PDD2023/labels \
  --out-dir D:/SD/Dataest/UAV-PDD2023/yolo_split \
  --val-size 0.1 \
  --test-size 0.1
"""

from __future__ import annotations

import argparse
import csv
import random
import shutil
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


DEFAULT_IMAGE_EXTS = (
    ".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff",
    ".JPG", ".JPEG", ".PNG", ".BMP", ".WEBP", ".TIF", ".TIFF",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Split YOLO images/labels into train/val/test with multi-format image support."
    )
    parser.add_argument("--img-dir", default="D:/CCF-A/Datasets/Power Tower Foreign Object Detection Dataset/Images", help="Image directory.")
    parser.add_argument("--label-dir", default="D:/CCF-A/Datasets/Power Tower Foreign Object Detection Dataset/laebls", help="YOLO label .txt directory.")
    parser.add_argument("--out-dir", default="D:/CCF-A/Datasets", help="Output root directory. It will contain images/ and labels/.")
    parser.add_argument("--val-size", type=float, default=0.1, help="Validation split ratio. Default: 0.1")
    parser.add_argument("--test-size", type=float, default=0.1, help="Test split ratio. Default: 0.1")
    parser.add_argument("--seed", type=int, default=0, help="Random seed. Default: 0")
    parser.add_argument(
        "--img-exts",
        nargs="*",
        default=list(DEFAULT_IMAGE_EXTS),
        help="Allowed image extensions, e.g. --img-exts .jpg .jpeg .png .bmp .webp",
    )
    parser.add_argument(
        "--include-unlabeled",
        action="store_true",
        help="Also split images that do not have label files. Empty label txt files will be created.",
    )
    parser.add_argument(
        "--clean",
        action="store_true",
        help="Remove existing images/ and labels/ subdirectories under out-dir before copying.",
    )
    parser.add_argument(
        "--copy-empty-labels",
        action="store_true",
        default=True,
        help="Create empty txt for images without labels when --include-unlabeled is used. Default: enabled.",
    )
    return parser.parse_args()


def normalize_exts(exts: Iterable[str]) -> Tuple[str, ...]:
    """Normalize extensions and include lower/upper variants for case-insensitive matching."""
    normalized = set()
    for ext in exts:
        ext = ext.strip()
        if not ext:
            continue
        if not ext.startswith("."):
            ext = "." + ext
        normalized.add(ext.lower())
        normalized.add(ext.upper())
    return tuple(sorted(normalized))


def validate_ratios(val_size: float, test_size: float) -> None:
    if not (0 <= val_size < 1):
        raise ValueError(f"val-size must be in [0, 1), got {val_size}")
    if not (0 <= test_size < 1):
        raise ValueError(f"test-size must be in [0, 1), got {test_size}")
    if val_size + test_size >= 1:
        raise ValueError(f"val-size + test-size must be < 1, got {val_size + test_size}")


def build_image_index(img_dir: Path, img_exts: Sequence[str]) -> Dict[str, Path]:
    """
    Build stem -> image path index.
    If duplicated stems exist, prefer the first path encountered after sorted traversal.
    """
    allowed = {e.lower() for e in img_exts}
    image_index: Dict[str, Path] = {}
    duplicates: Dict[str, List[Path]] = {}

    for path in sorted(img_dir.iterdir()):
        if not path.is_file():
            continue
        if path.suffix.lower() not in allowed:
            continue
        if path.stem in image_index:
            duplicates.setdefault(path.stem, [image_index[path.stem]]).append(path)
            continue
        image_index[path.stem] = path

    if duplicates:
        print("[WARN] Duplicate image stems detected. The first one is used:")
        for stem, paths in list(duplicates.items())[:20]:
            print(f"  {stem}: " + ", ".join(str(p.name) for p in paths))
        if len(duplicates) > 20:
            print(f"  ... and {len(duplicates) - 20} more duplicate stems")

    return image_index


def collect_samples(
    img_dir: Path,
    label_dir: Path,
    img_exts: Sequence[str],
    include_unlabeled: bool = False,
) -> Tuple[List[Tuple[str, Path, Optional[Path]]], List[str]]:
    """
    Return samples as (stem, image_path, label_path_or_none).
    Main mode uses label files as source of truth.
    """
    image_index = build_image_index(img_dir, img_exts)
    label_files = sorted(p for p in label_dir.iterdir() if p.is_file() and p.suffix.lower() == ".txt")

    samples: List[Tuple[str, Path, Optional[Path]]] = []
    missing_images: List[str] = []

    for label_path in label_files:
        stem = label_path.stem
        image_path = image_index.get(stem)
        if image_path is None:
            missing_images.append(label_path.name)
            continue
        samples.append((stem, image_path, label_path))

    if include_unlabeled:
        labeled_stems = {p.stem for p in label_files}
        for stem, image_path in sorted(image_index.items()):
            if stem not in labeled_stems:
                samples.append((stem, image_path, None))

    return samples, missing_images


def split_samples(
    samples: Sequence[Tuple[str, Path, Optional[Path]]],
    val_size: float,
    test_size: float,
    seed: int,
) -> Dict[str, List[Tuple[str, Path, Optional[Path]]]]:
    items = list(samples)
    rng = random.Random(seed)
    rng.shuffle(items)

    n = len(items)
    n_train = int(n * (1 - val_size - test_size))
    n_val = int(n * val_size)

    train = items[:n_train]
    val = items[n_train:n_train + n_val]
    test = items[n_train + n_val:]

    return {"train": train, "val": val, "test": test}


def prepare_output_dirs(out_dir: Path, clean: bool = False) -> None:
    if clean:
        for sub in ["images", "labels"]:
            target = out_dir / sub
            if target.exists():
                shutil.rmtree(target)

    for split in ["train", "val", "test"]:
        (out_dir / "images" / split).mkdir(parents=True, exist_ok=True)
        (out_dir / "labels" / split).mkdir(parents=True, exist_ok=True)


def copy_split(
    splits: Dict[str, List[Tuple[str, Path, Optional[Path]]]],
    out_dir: Path,
) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []

    for split_name, samples in splits.items():
        for stem, image_path, label_path in samples:
            dst_img = out_dir / "images" / split_name / image_path.name
            dst_label = out_dir / "labels" / split_name / f"{stem}.txt"

            shutil.copy2(image_path, dst_img)
            if label_path is not None:
                shutil.copy2(label_path, dst_label)
                label_status = "copied"
            else:
                dst_label.write_text("", encoding="utf-8")
                label_status = "created_empty"

            rows.append(
                {
                    "split": split_name,
                    "stem": stem,
                    "image_src": str(image_path),
                    "image_dst": str(dst_img),
                    "label_src": str(label_path) if label_path else "",
                    "label_dst": str(dst_label),
                    "label_status": label_status,
                }
            )

    return rows


def write_report(out_dir: Path, rows: List[Dict[str, str]], missing_images: List[str]) -> None:
    report_path = out_dir / "split_summary.csv"
    with report_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["split", "stem", "image_src", "image_dst", "label_src", "label_dst", "label_status"],
        )
        writer.writeheader()
        writer.writerows(rows)

    missing_path = out_dir / "missing_images.txt"
    missing_path.write_text("\n".join(missing_images), encoding="utf-8")


def main() -> None:
    args = parse_args()

    img_dir = Path(args.img_dir)
    label_dir = Path(args.label_dir)
    out_dir = Path(args.out_dir)
    img_exts = normalize_exts(args.img_exts)

    validate_ratios(args.val_size, args.test_size)

    if not img_dir.exists():
        raise FileNotFoundError(f"Image directory does not exist: {img_dir}")
    if not label_dir.exists():
        raise FileNotFoundError(f"Label directory does not exist: {label_dir}")

    samples, missing_images = collect_samples(
        img_dir=img_dir,
        label_dir=label_dir,
        img_exts=img_exts,
        include_unlabeled=args.include_unlabeled,
    )

    if not samples:
        raise RuntimeError(
            "No valid image-label samples found. Check image extensions, image directory, and label filenames."
        )

    splits = split_samples(samples, args.val_size, args.test_size, args.seed)
    prepare_output_dirs(out_dir, clean=args.clean)
    rows = copy_split(splits, out_dir)
    write_report(out_dir, rows, missing_images)

    print("Split finished.")
    print(f"Image directory: {img_dir}")
    print(f"Label directory: {label_dir}")
    print(f"Output directory: {out_dir}")
    print(f"Allowed image extensions: {', '.join(img_exts)}")
    print(f"Total valid samples: {len(samples)}")
    print(f"Train: {len(splits['train'])}, Val: {len(splits['val'])}, Test: {len(splits['test'])}")
    print(f"Labels with missing images: {len(missing_images)}")
    print(f"Report: {out_dir / 'split_summary.csv'}")
    print(f"Missing image list: {out_dir / 'missing_images.txt'}")


if __name__ == "__main__":
    main()
