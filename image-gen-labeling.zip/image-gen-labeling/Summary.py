from pathlib import Path
from collections import Counter
import xml.etree.ElementTree as ET


# 数据集路径
DATASET_ROOT = Path(r"D:\SD\Dataset_base\RoadDW26")
ANNOTATION_DIR = DATASET_ROOT / "Annotation"


def count_class_instances(annotation_dir: Path):
    class_counter = Counter()

    xml_files = list(annotation_dir.glob("*.xml"))

    for xml_file in xml_files:
        try:
            root = ET.parse(xml_file).getroot()

            # 一个 object 表示一个目标实例
            for obj in root.findall("object"):
                name_node = obj.find("name")

                if name_node is not None and name_node.text:
                    class_name = name_node.text.strip()
                    class_counter[class_name] += 1

        except ET.ParseError:
            print(f"XML 解析失败：{xml_file.name}")

    return class_counter


if __name__ == "__main__":
    counts = count_class_instances(ANNOTATION_DIR)

    print("=" * 45)
    print("各类别目标实例数")
    print("=" * 45)

    for class_name, count in counts.most_common():
        print(f"{class_name:<25} {count:>8}")

    print("=" * 45)
    print(f"类别总数：{len(counts)}")
    print(f"目标实例总数：{sum(counts.values())}")