import warnings
warnings.filterwarnings('ignore')

import os, tqdm, random, shutil
import torch
from diffusers import ZImagePipeline

class ImageGenerator:
    def __init__(self, model_name='Z-Image-Turbo'):
        self.pipe = None
        if model_name == 'Z-Image-Turbo':
            self.pipe = ZImagePipeline.from_pretrained(
                "/datasets/studio/huggingface/models/Z-Image-Turbo",
                torch_dtype=torch.bfloat16,
                low_cpu_mem_usage=False,
            )
            self.pipe.to("cuda")
            # Diffusers uses SDPA by default. Switch to Flash Attention for better efficiency if supported:
            self.pipe.transformer.set_attention_backend("flash")
    
    def __call__(self, prompt, save_path):
        image = self.pipe(
            prompt=prompt,
            height=720,
            width=1280,
            num_inference_steps=9,  # This actually results in 8 DiT forwards
            guidance_scale=0.0,     # Guidance should be 0 for the Turbo models
            generator=torch.Generator("cuda").manual_seed(torch.randint(0, 2**32, (1,)).item()),
        ).images[0]

        image.save(save_path)

def generate_uav_vehicle_prompts():
    """生成无人机视角下城市车辆检测 prompt 组合"""
    
    # 车辆类型
    vehicle_types = [
        'small sedans and compact cars',  # 小型轿车
        'SUVs and large sedans',  # SUV和大型轿车
        'buses and coaches',  # 公交车和大巴
        'trucks and cargo vehicles',  # 卡车和货车
        'vans and minivans',  # 面包车和小型客车
        'motorcycles and scooters',  # 摩托车和电动车
        'emergency vehicles like ambulances and fire trucks',  # 应急车辆-救护车消防车
        'construction vehicles and heavy machinery',  # 工程车辆和重型机械
        'mixed vehicle types including cars, buses and trucks'  # 混合车型
    ]
    
    # 车辆数量
    vehicle_counts = [
        '1-3 vehicles sparsely distributed',  # 极少-1-3辆
        '5-10 vehicles loosely scattered',  # 稀疏-5-10辆
        '15-25 vehicles moderately dense',  # 中等-15-25辆
        '30-50 vehicles in dense traffic',  # 密集-30-50辆
        '60-100 vehicles in heavy congestion',  # 拥堵-60-100辆
        'parking lot with 20-40 parked vehicles in organized rows'  # 停车场-20-40辆有序停放
    ]
    
    # 道路类型
    road_types = [
        'straight urban road with 2 lanes and sidewalks on both sides',  # 城市双车道直路带人行道
        'wide 4-lane city avenue with dedicated bike lanes',  # 城市四车道大道带非机动车道
        '6-8 lane highway with clear lane markings and emergency lanes',  # 高速公路6-8车道带应急车道
        'curved road with gentle turns and roadside barriers',  # 弯曲道路带护栏
        'intersection with crossroads, traffic lights, and zebra crossings',  # 十字路口带红绿灯和斑马线
        'T-junction intersection with pedestrian crossing signals',  # T型路口带行人过街信号
        'roundabout with circular traffic flow and center island',  # 环岛带中心绿化
        'highway exit ramp and merge area with guide signs',  # 高速出入口匝道带指示牌
        'parking lot with marked parking spaces and pedestrian walkways',  # 停车场带车位线和人行通道
        'residential area with narrow streets and parked cars along curbs'  # 居民区窄路路边停车
    ]
    
    # 无人机飞行高度
    altitudes = [
        'low altitude 20-30 meters, detailed vehicle view',  # 低空20-30米-细节清晰
        'medium altitude 50-80 meters, clear vehicle identification',  # 中空50-80米-可识别车型
    ]
    
    # 拍摄角度
    camera_angles = [
        'top-down bird\'s eye view at 90 degrees',  # 垂直俯视90度
    ]
    
    # 光照条件
    lightings = [
        'bright sunny day with strong shadows from vehicles',  # 强光-晴天车辆阴影明显
        'soft morning light at 8-9 AM with long shadows',  # 柔光-早晨8-9点长阴影
        'noon sunlight with minimal shadows directly below vehicles',  # 正午-阴影在车辆正下方
        'golden hour afternoon light at 4-5 PM',  # 黄昏-下午4-5点
        'overcast cloudy day with diffused lighting and no shadows',  # 阴天-漫射光无阴影
        'light rain with wet road surface reflections',  # 小雨-路面湿润有反光
        'after rain with water puddles reflecting sky',  # 雨后-水坑反射
        'foggy conditions with reduced visibility'  # 雾天-能见度降低
    ]
    
    # 季节与植被
    seasons = [
        'spring with green trees lining the roads',  # 春季-绿树成荫
        'summer with lush vegetation',  # 夏季-植被茂盛
        'autumn with yellow and orange foliage',  # 秋季-黄橙色树叶
        'winter with bare trees and possible snow patches',  # 冬季-光秃树木可能有雪
        'no vegetation, pure urban concrete environment'  # 无植被-纯城市混凝土环境
    ]
    
    # 城市环境
    urban_settings = [
        'downtown business district with high-rise buildings and office towers',  # 市中心商务区-高楼大厦
        'residential neighborhood with low-rise apartments and community facilities',  # 居民区-低层公寓和社区设施
        'bridge crossing over river with railings and street lamps',  # 桥梁-跨越河流带护栏路灯
        'tunnel entrance area with overhead signs and lighting'  # 隧道出入口带指示牌和照明
    ]
    
    # 交通状态
    traffic_states = [
        'free-flowing traffic with vehicles moving smoothly',  # 畅通-车辆流畅行驶
        'moderate traffic with some congestion',  # 中等拥堵
        'heavy traffic jam with stopped vehicles',  # 严重拥堵-车辆停滞
        'rush hour traffic with bumper-to-bumper vehicles',  # 高峰期-车辆首尾相连
        'all vehicles parked and stationary',  # 全部停放-静止状态
        'mixed moving and parked vehicles'  # 混合-行驶与停放车辆
    ]
    
    # 行人与非机动车（新增-更贴近现实）
    pedestrian_elements = [
        'few pedestrians walking on sidewalks',  # 少量行人在人行道
        'moderate crowd of pedestrians crossing at zebra crossings',  # 中等人群在斑马线过街
        'busy sidewalks with many pedestrians and street vendors',  # 繁忙人行道-行人和摊贩
        '5-10 cyclists and electric scooters in bike lanes',  # 5-10个骑行者和电动车在非机动车道
        '15-20 delivery scooters weaving through traffic',  # 15-20个外卖车穿梭
        'pedestrians waiting at bus stops with shelters',  # 行人在公交站台等候
        'people crossing street mid-block, jaywalking',  # 行人横穿马路
        'empty sidewalks with no pedestrians visible',  # 空旷人行道无行人
        'street performers or vendors occupying sidewalk space',  # 街头艺人或商贩占用人行道
        'children playing near residential areas with adults supervising'  # 居民区儿童玩耍有成人监护
    ]
    
    # 城市设施细节（新增-增强真实感）
    urban_details = [
        'street lights, traffic signs, and utility poles visible',  # 路灯、交通标志和电线杆
        'bus stops with waiting passengers and route information boards',  # 公交站台带候车乘客和路线牌
        'roadside trees casting shadows, trash bins and benches',  # 路边树木投影、垃圾桶和长椅
        'construction barriers and orange traffic cones in work zones',  # 施工围挡和橙色交通锥
        'outdoor cafe seating and shop awnings along street',  # 户外咖啡座和商店遮阳篷
        'parked bicycles and shared bike stations on sidewalks',  # 停放自行车和共享单车站点
        'street vendors with carts and temporary stalls',  # 街边摊贩推车和临时摊位
        'manhole covers, road markings, and painted arrows visible',  # 井盖、路面标线和箭头可见
        'advertising billboards and storefront signs',  # 广告牌和店铺招牌
        'green belts with shrubs separating lanes'  # 绿化带灌木分隔车道
    ]
    
    # 特殊场景
    special_scenes = [
        'normal traffic scene',  # 正常交通场景
    ]
    
    prompts = []
    
    # 遍历所有组合
    for vehicle_type in vehicle_types:
        for vehicle_count in vehicle_counts:
            for road_type in road_types:
                for altitude in altitudes:
                    for camera_angle in camera_angles:
                        for lighting in lightings:
                            for season in seasons:
                                for urban_setting in urban_settings:
                                    for traffic_state in traffic_states:
                                        for pedestrian in pedestrian_elements:
                                            for urban_detail in urban_details:
                                                for special_scene in special_scenes:
                                                    prompt = f"""Photorealistic aerial drone view of urban traffic scene. 
{vehicle_count} {vehicle_type} on {road_type}. 
{altitude}, {camera_angle}. 
{lighting}. {season}. 
{urban_setting} in background. 
{traffic_state}. 
{pedestrian}. 
{urban_detail}.
{special_scene}.
Clear road markings, lane lines, and traffic signs visible. 
Sharp focus on vehicles, realistic shadows and reflections. 
Professional aerial photography, 4K quality, high detail, natural urban atmosphere."""
                                                    prompts.append(prompt.replace('\n', ' ').strip())
    
    return prompts, 'uav_gen'

def generate_uav_road_defect_prompts():
    """生成无人机视角道路缺陷检测 prompt 组合，共8000条"""
    
    defect_types = [
        'one or several transverse pavement cracks extending across the driving direction, thin irregular dark surface lines with realistic widths of 3-15 millimeters, subtle branching and natural width variation',
        'one or several longitudinal pavement cracks extending approximately parallel to the driving direction, thin discontinuous dark surface lines with realistic widths of 3-15 millimeters',
        'one or several diagonal pavement cracks extending obliquely across the traffic lane, narrow irregular lines with a few short secondary branches and realistic widths of 3-15 millimeters',
        'localized network cracking composed of many fine interconnected polygonal surface lines within an area of approximately 0.5-2 square meters, without wide polygon gaps',
        'one or several small shallow potholes with irregular worn edges, realistic diameters of 15-60 centimeters and depths of approximately 1-5 centimeters',
        'one or several flat asphalt repair patches with rectangular or irregular boundaries, subtle color differences, realistic dimensions of 0.5-3 meters and narrow closed repair seams'
    ]
    
    counts = [
        'a single localized pavement defect surrounded by mostly intact asphalt',
        '2 separated pavement defects with large intact road areas between them',
        '3 small pavement defects sparsely distributed within one traffic lane',
        '4-5 localized pavement defects distributed along a short road section',
        'several small pavement defects sparsely distributed across adjacent traffic lanes'
    ]
    
    lightings = [
        'light rain with fine raindrops, uniformly wet asphalt, soft reflections and slightly reduced contrast',
        'moderate rain with visible rainfall, wet pavement, small shallow puddles and mild road spray',
        'steady rain with water-darkened asphalt, scattered reflections and realistic limited visibility',
        'after rain with damp pavement, irregular water stains, shallow puddles and reflected sky light',
        'light snowfall with sparse snowflakes, thin snow near the road edges and mostly exposed asphalt',
        'moderate snowfall with discontinuous snow coverage, slush and visible tire tracks',
        'after snowfall with small snow patches, slush along the curbs and exposed pavement around the defects',
        'winter weather with thin uneven snow coverage while the main road defects remain visible',
        'light fog with soft atmospheric haze, slightly reduced contrast and clear nearby pavement texture',
        'moderate fog with muted colors, diffused light and reduced long-distance visibility',
        'dense morning fog with low contrast while the inspected road section remains visible',
        'fog after rain with wet pavement, soft reflections and hazy surrounding scenery',
        'nighttime illuminated by evenly spaced street lamps with realistic shadows and mild sensor noise',
        'rainy night with controlled wet-road reflections, street lighting and limited headlight glare',
        'foggy night with diffused street lamps, low contrast and visible pavement texture',
        'very low-light dawn or dusk with dim ambient illumination, subtle noise and preserved defect details'
    ]
    
    occlusions = [
        'fully visible on the exposed road surface with no object covering the defect',
        'slightly affected by soft shadows while the complete defect geometry remains visible',
        'seen through a thin transparent water film without changing its physical dimensions',
        'partially surrounded by snow or slush while most of the defect remains exposed',
        'located near sparse vehicles without being covered by vehicles or strong shadows'
    ]
    
    viewpoints = [
        'low-altitude UAV view from 15-30 meters with a stabilized top-down bird\'s-eye perspective at 90 degrees',
        'medium-altitude UAV view from 30-50 meters with a stabilized near-vertical perspective at 82-88 degrees'
    ]
    
    backgrounds = [
        'straight urban asphalt road with lane markings, intact sidewalks, roadside vegetation and guardrails',
        'wide multilane city avenue with intact intersections, traffic signs, street lights and roadside buildings',
        'residential asphalt road with parked vehicles, intact curbs, trees and drainage facilities',
        'highway or bridge pavement with intact guardrails, emergency lanes and directional markings',
        'road intersection or T-junction with intact zebra crossings, turning arrows, manhole covers and sidewalks'
    ]
    
    prompts = []
    
    for defect_type in defect_types:
        for count in counts:
            for lighting in lightings:
                for occlusion in occlusions:
                    for viewpoint in viewpoints:
                        for background in backgrounds:
                            prompt = f"""Photorealistic aerial UAV image for road pavement defect detection.
{count} consisting exclusively of {defect_type}.
{lighting}. The pavement defect is {occlusion}.
{viewpoint}. {background}.
The visual scale and appearance of the pavement damage must match real UAV road inspection photographs.
Linear cracks appear as narrow dark gray or black surface lines embedded in the asphalt texture, with subtle jagged paths, slight discontinuities, occasional short branches and low-contrast edges.
At UAV image scale, each linear crack should appear only as a very thin line, normally about one twentieth to one sixth of the width of a nearby lane marking.
Only a few short local crack junctions may appear slightly darker or thicker, but no part may resemble a trench, canyon, structural separation or open ground gap.
The asphalt aggregate texture remains visible immediately beside the crack, with no vertical sidewalls, exposed soil, deep interior shadow or displaced pavement slabs.
Transverse, longitudinal and diagonal cracks may extend for several meters across the road while remaining consistently thin and shallow.
Network cracking remains confined to small localized pavement regions and consists of fine interconnected lines rather than large separated polygon blocks.
Potholes remain localized, shallow and naturally worn, with no crater-like depth or catastrophic pavement collapse.
Repair patches remain flat and level with the surrounding road, with subtle tonal variation and narrow realistic seams.
All cracks, potholes and repair patches are physically confined to the drivable asphalt or concrete carriageway.
Sidewalks, curbs, buildings, roofs, walls, vehicles, guardrails, traffic signs, soil, vegetation and every other non-road surface remain intact and completely free of cracks.
The defects remain distinguishable from lane markings, painted arrows, shadows, tire marks, oil stains, water reflections, snow boundaries, manhole covers, drainage grates and normal asphalt texture.
No giant cracks, no exaggerated black fissures, no earthquake damage, no ground rupture, no road splitting, no collapsed pavement and no damage outside the road surface.
Realistic rain, snow, fog, nighttime and low-light imaging effects, natural colors, physically plausible illumination and professional UAV road inspection photography, 4K quality."""
                            prompts.append(prompt.replace('\n', ' ').strip())
    
    import random
    random.Random(42).shuffle(prompts)
    prompts = prompts[:8000]
    
    return prompts, 'uav_road_defect_gen'
if __name__ == '__main__':
    model = ImageGenerator('Z-Image-Turbo')
    gen_image_num = 10000
    all_prompts, save_folder = generate_uav_road_defect_prompts()
    # all_prompts, save_folder = generate_uav_vehicle_prompts()
    random.shuffle(all_prompts)
    save_folder = os.path.join(save_folder, 'images')
    if not os.path.exists(save_folder):
        os.makedirs(save_folder)
    for idx in tqdm.tqdm(range(gen_image_num)):
        model(all_prompts[idx], f'{save_folder}/image_{idx:06d}.png')