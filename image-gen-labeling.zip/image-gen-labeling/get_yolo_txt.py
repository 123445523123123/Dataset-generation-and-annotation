import os, glob, random

if __name__ == '__main__':
    train_ratio = 0.7
    val_ratio = 0.1
    test_ratio = 0.2

    image_path = glob.glob('/root/image-gen/uav_gen/images/*')
    random.shuffle(image_path)

    with open('/root/image-gen/train.txt', 'w+') as f:
        f.write('\n'.join(image_path[:int(len(image_path) * train_ratio)]))
    
    with open('/root/image-gen/val.txt', 'w+') as f:
        f.write('\n'.join(image_path[int(len(image_path) * train_ratio):int(len(image_path) * (train_ratio + val_ratio))]))
    
    with open('/root/image-gen/test.txt', 'w+') as f:
        f.write('\n'.join(image_path[int(len(image_path) * (train_ratio + val_ratio)):]))